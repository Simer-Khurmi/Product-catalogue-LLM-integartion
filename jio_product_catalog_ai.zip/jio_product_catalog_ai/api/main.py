from fastapi import FastAPI, HTTPException
from models import QueryRequest
from llama_connector import query_to_action_plan
from tmf_client import list_offers, get_offer_by_id
from order_client import place_order
from customer_client import get_customer_info
from usage_client import get_usage
from billing_client import get_balance

app = FastAPI(title="Jio AI Telecom Assistant")

@app.post("/query")
def process_query(req: QueryRequest):
    plan = query_to_action_plan(req.query)

    if plan.action == "list_offers":
        return list_offers(plan.filters)
    elif plan.action == "get_offer":
        if not plan.id:
            raise HTTPException(400, "Missing id")
        return get_offer_by_id(plan.id)
    elif plan.action == "place_order":
        return place_order(plan.filters)
    elif plan.action == "get_customer_info":
        if not plan.id:
            raise HTTPException(400, "Missing id")
        return get_customer_info(plan.id)
    elif plan.action == "get_usage":
        return get_usage(plan.id)
    elif plan.action == "get_balance":
        return get_balance(plan.id)
    else:
        raise HTTPException(400, f"Invalid action: {plan.action}")
