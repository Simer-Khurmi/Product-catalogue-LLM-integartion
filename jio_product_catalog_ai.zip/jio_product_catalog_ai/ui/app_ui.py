import streamlit as st
import requests

API_URL = "http://127.0.0.1:8005/query"

st.title("📱 Jio AI Telecom Assistant")

if "history" not in st.session_state:
    st.session_state.history = []

query = st.text_input("Ask your query (e.g. 'Recharge with 199 plan', 'My balance')")

if st.button("Send"):
    if query:
        st.session_state.history.append({"role":"user","text":query})
        try:
            resp = requests.post(API_URL, json={"query": query}).json()
            st.session_state.history.append({"role":"bot","text":resp})
        except Exception as e:
            st.session_state.history.append({"role":"bot","text":str(e)})

for item in st.session_state.history[::-1]:
    st.write(f"**{item['role'].title()}:** {item['text']}")
