# Quick Start

1) Python 3.10+ recommended
2) pip install -r requirements.txt
3) cp .env.example .env
   - If you have a live TMF620 backend, set TMF_BASE_URL
   - Else leave MOCK_MODE=true to use MOCK_DATA.json
4) uvicorn main:app --reload
5) Open http://127.0.0.1:8000/docs (Swagger UI)
6) Try POST /query with payloads:

Examples:
{
  "query": "show all prepaid plans under 500"
}
{
  "query": "details of offer 1002"
}
{
  "query": "list broadband offers with price >= 700 and active"
}
